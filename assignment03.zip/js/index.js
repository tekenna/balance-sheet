const description = document.querySelector("#description")
const AMOUNT = parseInt(document.querySelector("#amount"))
const BTN = document.querySelector(".btn")


var list1 = []
var list2 = []
var content = description.value
var amount = AMOUNT.value

var total = []

function start(event) {
    event.preventDefault()
    let content = description.value
    let amount = AMOUNT.value
    list1.push(content)
    list2.push(amount)
    console.log(list2)
        /*
        console.log(list1.length)
        console.log(list2.length)*/
    var list = list2.length
    var i = 0
    while (i < list) {
        console.log(list2[i])
        i++
    }
}



BTN.addEventListener("click", start, false)